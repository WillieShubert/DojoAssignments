var mongoose = require('mongoose');
console.log("mongoose connection and model loading");
mongoose.connect('mongodb://localhost/YOUR_DB_NAME');
