FactoryGirl.define do
  factory :secret do
    content "The password is....clam chowder"
    user nil
  end
end
