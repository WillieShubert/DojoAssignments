FactoryGirl.define do
  factory :user do
    name "Willie Shubert"
    email "willie@email.com"
    password "password"
    password_confirmation "password"
  end
end
