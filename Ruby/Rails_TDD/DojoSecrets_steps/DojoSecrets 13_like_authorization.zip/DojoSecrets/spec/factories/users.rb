FactoryGirl.define do
  factory :user do
    name "Tommy"
    email "tommy@gmail.com"
    password "password"
    password_confirmation "password"
  end
end
