class SecretsController < ApplicationController
  def index
  end
end
